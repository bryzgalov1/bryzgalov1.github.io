import { Status, TCellId, TChanged, TLifeMapData, TStatus } from "./types";
import createLifeMapData from "./utils/createLifeMapData";
import createNewGeneration from "./utils/createNewGeneration";

class LifeMap {
    #lifeMapData: TLifeMapData;
    #changed: TChanged;

    constructor() {
        this.#lifeMapData = {
            width: 0,
            height: 0,
            cellSize: 20,
            cellMap: {},
        };
        this.#changed = {};
    }

    async updateMapSize(width: number, height: number, cellSize: number) {
        const oldCellMap = this.#lifeMapData.cellMap;

        const lifeMapData = await createLifeMapData({
            cellSize,
            oldCellMap,
            height,
            width,
        });

        this.#lifeMapData = lifeMapData;
        this.#changed = {};
    }

    setStatus(cellId: TCellId, status: TStatus) {
        const cell = this.#lifeMapData.cellMap[cellId];
        if (cell) {
            cell.status = status;
            this.#changed = {};
        }
    }

    toggleCellStatus(cellId: TCellId) {
        const cell = this.#lifeMapData.cellMap[cellId];
        if (cell) {
            const status = cell.status === Status.LIVE ? Status.DEAD : Status.LIVE;
            this.setStatus(cellId, status);
        }
    }

    get lifeMapData() {
        return this.#lifeMapData;
    }

    createNewGeneration() {
        const [
            newLifeMap,
            changed,
        ] = createNewGeneration(this.#lifeMapData, this.#changed);

        this.#lifeMapData = newLifeMap;
        this.#changed = changed;
    }
};

export default LifeMap;
