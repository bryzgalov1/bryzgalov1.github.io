import { Status, TLifeMapData } from "./types";
import getCellId from "./utils/getCellId";

type TCellClick = (cellX: number, cellY: number) => void;

class LifeMapView {
    #element: HTMLDivElement;
    #cellClicks: TCellClick[] = [];

    #cellSize?: number;

    constructor() {
        const element = document.getElementById('lifeMap') as HTMLDivElement;
        this.#element = element;
    }

    #getEntityElement(cellX: number, cellY: number, cellSize: number): HTMLElement {
        const cellId = getCellId(cellX, cellY);

        const left = cellX * cellSize + cellX;
        const top = cellY * cellSize + cellY;

        const style = `left: ${left}px;top: ${top}px;width: ${cellSize}px;height: ${cellSize}px;`;

        const element = document.createElement('DIV');

        element.className = 'lifeMap__entity';
        element.id = cellId;
        element.style.cssText = style;

        return element;
    }

    #setElementStyle(lifeMap: TLifeMapData) {
        const {
            width,
            height,
            cellSize,
        } = lifeMap;

        const appMapWidth = width + width * cellSize;
        const appMapHeight = height + height * cellSize;

        const color = '#cdcdcd';

        const cssText = `width: ${appMapWidth}px;height: ${appMapHeight}px;
        background-image: 
        repeating-linear-gradient(to right, transparent, transparent ${cellSize}px, ${color}, ${color} ${cellSize + 1}px),
        repeating-linear-gradient(to bottom, transparent, transparent ${cellSize}px, ${color}, ${color} ${cellSize + 1}px);`;

        this.#element.style.cssText = cssText;
    }

    #addEntity(lifeMap: TLifeMapData) {
        const {
            width,
            height,
            cellSize,
        } = lifeMap;

        for (let cellY = 0; cellY < height; cellY++) {
            for (let cellX = 0; cellX < width; cellX++) {
                const cellId = getCellId(cellX, cellY);
                const cell = lifeMap.cellMap[cellId];
                if (cell.status === Status.LIVE) {
                    const entityElement = this.#getEntityElement(cellX, cellY, cellSize);
                    this.#element.appendChild(entityElement);
                }
            }
        }
    }

    #elementOnClick = (event: MouseEvent) => {
        if (this.#cellSize) {
            const target = event.target as HTMLDivElement;

            const rect = target.getBoundingClientRect();
            const xPosition = event.clientX - rect.left;
            const yPosition = event.clientY - rect.top;

            const cellX = Math.floor(xPosition / (this.#cellSize + 1));
            const cellY = Math.floor(yPosition / (this.#cellSize + 1));

            this.#cellClicks.forEach(call => call(cellX, cellY));
        }
    }

    init(lifeMap: TLifeMapData) {
        this.#element.innerHTML = '';
        this.#element.removeEventListener('click', this.#elementOnClick);

        this.#cellSize = lifeMap.cellSize;
        this.#setElementStyle(lifeMap);
        this.#addEntity(lifeMap);
        this.#element.addEventListener('click', this.#elementOnClick);
    }

    update(lifeMap: TLifeMapData) {
        const COUNT_UPDATE = 100;
        return new Promise<void>((resolve) => {
            const thisElement = this.#element;
            const thisGetEntityElement = this.#getEntityElement;

            const list = Object.values(lifeMap.cellMap);
            function* updatePartGenerator() {
                let index = 0;
                for (const cell of list) {
                    index++;
                    const element = document.getElementById(cell.cellId);
                    if (cell.status === Status.LIVE) {
                        if (element === null) {
                            const entityElement = thisGetEntityElement(cell.cellX, cell.cellY, lifeMap.cellSize);
                            thisElement.appendChild(entityElement);
                        }
                    }
                    if (cell.status === Status.DEAD) {
                        if (element !== null) {
                            thisElement.removeChild(element);
                        }
                    }
                    if (index % COUNT_UPDATE === 0) {
                        yield;
                    }
                }
                yield;
            }

            const updatePart = updatePartGenerator();

            const done = () => {
                const next = updatePart.next();
                if (next.done) {
                    resolve();
                } else {
                    window.setTimeout(() => {
                        done();
                    }, 0);
                }
            }

            done();
        });
    }

    onCellClick(call: TCellClick) {
        this.#cellClicks.push(call);
    }
};

export default LifeMapView;
