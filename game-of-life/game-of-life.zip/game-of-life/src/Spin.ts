class Spin {
    #element: HTMLDivElement;

    constructor() {
        const element = document.getElementById('spin') as HTMLDivElement;
        this.#element = element;
        this.#element.style.cssText = 'display: none';
    }

    show() {
        this.#element.style.cssText = 'display: block;';
    }

    hide() {
        this.#element.style.cssText = 'display: none';
    }
};

export default Spin;
