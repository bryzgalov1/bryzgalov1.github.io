import LifeMap from './LifeMap';
import LifeMapView from './LifeMapView';
import Spin from './Spin';
import getCellId from './utils/getCellId';
import { Status } from './types';

import './style.css';

const lifeMap = new LifeMap();
const lifeMapView = new LifeMapView();
const spin = new Spin();

lifeMapView.init(lifeMap.lifeMapData);

const lifeMapSize = document.getElementById('lifeMapSize') as HTMLFormElement;
if (lifeMapSize) {
    lifeMapSize.addEventListener('submit', async (event) => {
        event.preventDefault();
        const formData = new FormData(lifeMapSize);
        const width = formData.get('width');
        const height = formData.get('height');
        const cellSize = formData.get('cellSize');
        if (
            width !== null &&
            height !== null &&
            cellSize !== null
        ) {
            spin.show();
            await lifeMap.updateMapSize(+width, +height, +cellSize);
            spin.hide();
            lifeMapView.init(lifeMap.lifeMapData);
        }
    });
}

lifeMapView.onCellClick(async (cellX, cellY) => {
    const cellId = getCellId(cellX, cellY);
    lifeMap.toggleCellStatus(cellId);
    await lifeMapView.update(lifeMap.lifeMapData);
});

const playNext = document.getElementById('playNext') as HTMLFormElement;
if (playNext) {
    playNext.addEventListener('click', async (_event) => {
        lifeMap.createNewGeneration();
        spin.show();
        await lifeMapView.update(lifeMap.lifeMapData);
        spin.hide();
    });
}

function randomInteger(min: number, max: number): number {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

const addRandom = document.getElementById('addRandom') as HTMLFormElement;
if (addRandom) {
    addRandom.addEventListener('click', async (_event) => {
        const {
            width,
            height,
        } = lifeMap.lifeMapData;

        const count = Math.floor((width * height) * 15 / 100);

        for (let index = 0; index < count; index++) {
            const cellX = randomInteger(0, width);
            const cellY = randomInteger(0, height);

            const cellId = getCellId(cellX, cellY);
            lifeMap.setStatus(cellId, Status.LIVE);
        }
        spin.show();
        await lifeMapView.update(lifeMap.lifeMapData);
        spin.hide();
    });
}

let isStop = true;

async function run() {
    if (!isStop) {
        lifeMap.createNewGeneration();
        await lifeMapView.update(lifeMap.lifeMapData);
        window.setTimeout(() => {
            run();
        }, 150);
    }
}

const playRun = document.getElementById('playRun') as HTMLFormElement;
if (playRun) {
    playRun.addEventListener('click', (_event) => {
        if (isStop) {
            isStop = false;
            run();
        }
    });
}

const playStop = document.getElementById('playStop') as HTMLFormElement;
if (playStop) {
    playStop.addEventListener('click', (_event) => {
        isStop = true;
    });
}