export const Status = {
    LIVE: 'LIVE',
    DEAD: 'DEAD',
} as const;

export type TStatus = keyof typeof Status;

export type TCellId = string;

export type TCell = {
    cellId: TCellId;
    cellX: number;
    cellY: number;
    status: TStatus;
    neighbours: TCellId[];
};

export type TCellMap = {
    [cellId: string]: TCell;
};

export type TLifeMapData = {
    width: number;
    height: number;
    cellSize: number;
    cellMap: TCellMap;
};

export type TChanged = {
    [cellId: string]: true;
};
