import { TLifeMapData, TCellMap, Status } from '../types';
import getCellId from './getCellId';
import getNeighbours from './getNeighbours';
import getCellIds from './getCellIds';

type TProps = {
    cellSize: TLifeMapData['cellSize'],
    oldCellMap: TLifeMapData['cellMap'],
    width: TLifeMapData['width'],
    height: TLifeMapData['height'],
};

const createLifeMapData = (props: TProps): Promise<TLifeMapData> => {
    return new Promise((resolve) => {
        const {
            cellSize,
            width,
            height,
            oldCellMap,
        } = props;

        const cellMap: TCellMap = {};

        const getPartCellIds = getCellIds(width, height, 999);

        const addTocellMap = () => {
            const part = getPartCellIds.next();

            if (part.done) {
                const lifeMapData: TLifeMapData = {
                    cellSize,
                    width,
                    height,
                    cellMap,
                };
                resolve(lifeMapData);
                return;
            } else {
                const partValue = part.value;

                for (let index = 0; index < partValue.length; index++) {
                    const element = partValue[index];
                    const [cellX, cellY] = element;

                    const cellId = getCellId(cellX, cellY);
                    const neighbours = getNeighbours({
                        width,
                        height,
                        cellX,
                        cellY,
                    });

                    const status = !!oldCellMap[cellId] ? oldCellMap[cellId].status : Status.DEAD;

                    cellMap[cellId] = {
                        cellId,
                        cellX,
                        cellY,
                        status,
                        neighbours,
                    };
                }

                window.setTimeout(() => {
                    addTocellMap();
                }, 0);
            }
        };

        addTocellMap();
    });
};

export default createLifeMapData;
