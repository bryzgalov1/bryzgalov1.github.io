import { TLifeMapData, TCellId } from "../../types";
import { TTmpStore } from "./types";
import newGenerationCellAndNeighbours from "./newGenerationCellAndNeighbours";

let tmpStore: TTmpStore = {};

type TChanged = {
    [cellId: string]: true;
};

type TCreateNewGeneration = [
    TLifeMapData,
    TChanged
];

const createNewGeneration = (prevLifeMap: TLifeMapData, oldChanged: TChanged): TCreateNewGeneration => {
    // Cписок клеток для просмотра в последующем поколении
    const newChanged: TChanged = {};

    tmpStore = {};

    const newLifeMap: TLifeMapData = JSON.parse(JSON.stringify(prevLifeMap));

    const oldChangedCellIds = Object.keys(oldChanged);

    const cellIdList: TCellId[] = (() => {
        if (oldChangedCellIds.length > 0) {
            return oldChangedCellIds;
        } else {
            const list = Object.keys(newLifeMap.cellMap);
            return list;
        }
    })();

    for (const cellId of cellIdList) {
        const cell = newLifeMap.cellMap[cellId];
        const addToChanged = newGenerationCellAndNeighbours({
            cell,
            newLifeMap,
            prevLifeMap,
            tmpStore,
        });
        if (addToChanged) {
            newChanged[cell.cellId] = true;
            cell.neighbours.forEach((neighbourCellId) => {
                newChanged[neighbourCellId] = true;
            });
        }
    }

    return [
        newLifeMap,
        newChanged,
    ];
};

export default createNewGeneration;