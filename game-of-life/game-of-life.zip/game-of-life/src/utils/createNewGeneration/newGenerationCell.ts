import { Status, TCell, TLifeMapData } from "../../types";
import getNeighboursLiveLength from "../getNeighboursLiveLength";
import { NewGenerationCellEvent, TNewGenerationCellEvent, TTmpStore } from "./types";

type TProps = {
    cell: TCell;
    newLifeMap: TLifeMapData;
    prevLifeMap: TLifeMapData;
    tmpStore: TTmpStore;
};
type TNewGenerationCell = (props: TProps) => TNewGenerationCellEvent;

const newGenerationCell: TNewGenerationCell = (props) => {
    const {
        cell,
        newLifeMap,
        prevLifeMap,
        tmpStore,
    } = props;

    // Если для этой клетки уже просчитывали возвращаем сразу результат
    if (tmpStore[cell.cellId]) {
        return tmpStore[cell.cellId];
    }

    let newGenerationCellEvent: TNewGenerationCellEvent = NewGenerationCellEvent.DID_NOT_CHANGE;

    // Количество соседних живых клеток
    const liveLength = getNeighboursLiveLength(prevLifeMap, cell.neighbours);

    if (cell.status === Status.DEAD) {
        if (liveLength === 3) {
            // Родится
            newLifeMap.cellMap[cell.cellId].status = Status.LIVE;
            newGenerationCellEvent = NewGenerationCellEvent.WAS_BORN;
        }
    }

    if (cell.status === Status.LIVE) {
        if (
            liveLength === 2 ||
            liveLength === 3
        ) {
            // Не изменится
            newGenerationCellEvent = NewGenerationCellEvent.DID_NOT_CHANGE;
        } else {
            // Умрёт
            newLifeMap.cellMap[cell.cellId].status = Status.DEAD;
            newGenerationCellEvent = NewGenerationCellEvent.DIED;
        }
    }

    tmpStore[cell.cellId] = newGenerationCellEvent;

    return newGenerationCellEvent;
};

export default newGenerationCell;
