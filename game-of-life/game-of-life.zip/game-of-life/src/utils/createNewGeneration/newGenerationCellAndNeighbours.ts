import { TCell, TLifeMapData } from "../../types";
import newGenerationCell from "./newGenerationCell";
import { TTmpStore } from "./types";

// Cписок клеток для просмотра в последующем поколении
// Если какая-либо клетка и все её соседи не изменились при текущем обсчёте нового поколения, то эта клетка не изменится и при следующем проходе.

type TAddToChanged = boolean;
type TProps = {
    cell: TCell;
    newLifeMap: TLifeMapData;
    prevLifeMap: TLifeMapData;
    tmpStore: TTmpStore;
};
type TNewGenerationCellAndNeighbours = (props: TProps) => TAddToChanged;

const newGenerationCellAndNeighbours: TNewGenerationCellAndNeighbours = (props) => {
    const {
        cell,
        newLifeMap,
        prevLifeMap,
        tmpStore,
    } = props;

    let addToChanged: TAddToChanged = false;

    const eventCell = newGenerationCell({
        cell,
        newLifeMap,
        prevLifeMap,
        tmpStore,
    });
    if (
        eventCell === 'DIED' ||
        eventCell === 'WAS_BORN'
    ) {
        addToChanged = true;
    }

    for (const neighbourCellId of cell.neighbours) {
        const neighbourCell = prevLifeMap.cellMap[neighbourCellId];

        const eventNeighbour = newGenerationCell({
            cell: neighbourCell,
            newLifeMap,
            prevLifeMap,
            tmpStore,
        });
        if (
            eventNeighbour === 'DIED' ||
            eventNeighbour === 'WAS_BORN'
        ) {
            addToChanged = true;
        }
    }

    return addToChanged;
};

export default newGenerationCellAndNeighbours;