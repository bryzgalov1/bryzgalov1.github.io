import { TCellId } from "../../types";

export const NewGenerationCellEvent = {
    WAS_BORN: 'WAS_BORN',
    DIED: 'DIED',
    DID_NOT_CHANGE: 'DID_NOT_CHANGE',
} as const;

export type TNewGenerationCellEvent = keyof typeof NewGenerationCellEvent;

export type TTmpStore = {
    [cellId: TCellId]: TNewGenerationCellEvent;
};
