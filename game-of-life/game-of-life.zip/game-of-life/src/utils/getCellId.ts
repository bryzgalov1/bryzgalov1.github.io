import { TCell, TCellId } from '../types';

const getCellId = (cellX: TCell['cellX'], cellY: TCell['cellY']): TCellId => {

    const cellId = `x${cellX}-y${cellY}`;

    return cellId;
};

export default getCellId;
