import { TCell } from "../types";

type TData = [TCell['cellX'], TCell['cellY']];

function* getCellIds(width: number, height: number, count: number): Generator<TData[], void, unknown> {
    let list: TData[] = [];

    for (let cellY = 0; cellY < height; cellY++) {
        for (let cellX = 0; cellX < width; cellX++) {

            list.push([cellX, cellY]);
            if (list.length === count) {
                yield list;
                list = [];
            }
        }
    }

    yield list;
};

export default getCellIds;
