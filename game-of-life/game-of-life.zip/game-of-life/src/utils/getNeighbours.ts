import { TCellId } from "../types";
import getCellId from "./getCellId";

type TProps = {
    width: number;
    height: number;

    cellX: number;
    cellY: number;
};

const getNeighbours = (props: TProps): TCellId[] => {
    const {
        width,
        height,

        cellX,
        cellY,
    } = props;

    let left = cellX - 1;
    let right = cellX + 1;

    if (left < 0) {
        left = width - 1;
    };
    if (right >= width) {
        right = 0;
    };

    let top = cellY - 1;
    let bottom = cellY + 1;

    if (top < 0) {
        top = height - 1;
    };
    if (bottom >= height) {
        bottom = 0;
    };

    const neighbours = [
        getCellId(left, top),
        getCellId(cellX, top),
        getCellId(right, top),

        getCellId(right, cellY),

        getCellId(right, bottom),
        getCellId(cellX, bottom),
        getCellId(left, bottom),

        getCellId(left, cellY),
    ];

    return neighbours;
};

export default getNeighbours;
