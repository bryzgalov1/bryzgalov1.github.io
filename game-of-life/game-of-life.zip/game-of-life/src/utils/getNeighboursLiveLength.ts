import { Status, TCell, TLifeMapData } from "../types";

type TGetNeighboursLiveLength = (lifeMap: TLifeMapData, neighboursIds: TCell['neighbours']) => number;

/**
 * Количество соседних живых клеток
 */
const getNeighboursLiveLength: TGetNeighboursLiveLength = (lifeMap, neighboursIds) => {
    const liveLength = neighboursIds.reduce((acc, cellId) => {
        const itemCell = lifeMap.cellMap[cellId];
        if (itemCell.status === Status.LIVE) {
            return acc + 1;
        }
        return acc;
    }, 0);

    return liveLength;
};

export default getNeighboursLiveLength;
