const log = {
    error(text: string) {
        console.error(text);
    }
};

export default log;
